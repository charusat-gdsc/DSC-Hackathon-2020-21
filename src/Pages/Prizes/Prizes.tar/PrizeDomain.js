import React from 'react';
import classes from './Prizes.module.css';
import PrizeWinner from './PrizeWinner';


const PrizeDomain = (props) => {
    return (
        <div className = {classes.bg}>
            <center className = {classes.domainName}>{props.domainName}</center>
            <div className = {classes.flexContainer}>
                <PrizeWinner pos = "S"/>
                <PrizeWinner pos = "F"/>
                <PrizeWinner pos = "T"/>
            </div>
        </div>
    )
}
export default PrizeDomain;