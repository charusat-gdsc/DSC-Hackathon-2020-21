import React from 'react';
import prizeClasses from './Prizes.module.css';
import judgeClasses from '../Judges/Judges.module.css';
import PrizeDomain from './PrizeDomain';
import Footer from '../../Components/Footer/Footer'

const Prizes = () => {
    // NEED TO CHANGE THIS TO PROPS
    return (
        <div>
            <div className = {[prizeClasses.imageContainer].join(' ')}>
                <div className={judgeClasses.dscLogo}></div>
                <span className={judgeClasses.homeText}>Home</span>
            </div>
            <PrizeDomain domainName = "AI/ML Domain" />
            <PrizeDomain domainName = "Full Stack App Development Domain" />
            <div className = {prizeClasses.prizeNote}><center>Some selected projects exhibiting extraordinary creativity and implementation will be given swags. All participants making it to the final round will be awarded participation certificates.</center></div>
            <Footer />
        </div>
    )
};

export default Prizes;